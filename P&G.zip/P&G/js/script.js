$(function(){
    "use strict";
    feather.replace();
    // Popular slider 
    $(".popular_slider").slick({
        slidesToShow:3,
        centerMode:true,
        centerPadding: "150px",
        arrows:false,
        focusOnSelect:true
    })
})

